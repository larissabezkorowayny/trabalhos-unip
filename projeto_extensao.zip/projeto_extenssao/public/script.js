function agendar() {
    alert("Entre em contato pelo Instagram para agendar!");
  }