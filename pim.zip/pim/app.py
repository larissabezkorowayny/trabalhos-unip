from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():

    relatorio = None

    if request.method == "POST":

        papel = float(request.form["papel"])
        plastico = float(request.form["plastico"])
        metal = float(request.form["metal"])
        vidro = float(request.form["vidro"])
        organico = float(request.form["organico"])

        reciclavel = papel + plastico + metal + vidro

        total = reciclavel + organico

        porcentagem = (reciclavel / total) * 100

        if porcentagem >= 70:
            mensagem = "Excelente índice de reciclagem!"
        elif porcentagem >= 50:
            mensagem = "Bom índice de reciclagem."
        else:
            mensagem = "A reciclagem precisa melhorar."

        relatorio = {
            "papel": papel,
            "plastico": plastico,
            "metal": metal,
            "vidro": vidro,
            "organico": organico,
            "reciclavel": reciclavel,
            "total": total,
            "porcentagem": round(porcentagem, 1),
            "mensagem": mensagem
        }

    return render_template("index.html", relatorio=relatorio)

if __name__ == "__main__":
    app.run(debug=True)