from flask import Flask, request, jsonify, send_from_directory
import sqlite3
from pathlib import Path
 
app = Flask(__name__)
 
DB = Path(__file__).resolve().parent / "minerais.db"
 
print("Banco utilizado:", DB)
 
 
def conectar():
    return sqlite3.connect(DB)
 
 
def criar_banco():
    with conectar() as con:
        con.execute("""
            CREATE TABLE IF NOT EXISTS minerais (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL UNIQUE,
                categoria TEXT NOT NULL,
                quantidade REAL NOT NULL,
                origem TEXT NOT NULL,
                status TEXT NOT NULL,
                simbolo TEXT NOT NULL
            )
        """)
 
        total = con.execute(
            "SELECT COUNT(*) FROM minerais"
        ).fetchone()[0]
 
        if total == 0:
            con.executemany("""
                INSERT INTO minerais
                (nome, categoria, quantidade, origem, status, simbolo)
                VALUES (?, ?, ?, ?, ?, ?)
            """, [
                ("Lítio", "Mineral crítico", 420, "Unidade Norte", "Em estoque", "Li"),
                ("Neodímio", "Terra rara", 280, "Unidade Leste", "Em processamento", "Nd"),
                ("Cobalto", "Mineral crítico", 390, "Unidade Central", "Em estoque", "Co"),
                ("Disprósio", "Terra rara", 190, "Unidade Sul", "Baixo estoque", "Dy")
            ])
 
 
@app.route("/")
def inicio():
    return send_from_directory(".", "index.html")
 
 
@app.route("/<path:arquivo>")
def arquivos(arquivo):
    return send_from_directory(".", arquivo)
 
 
@app.route("/api/minerais", methods=["GET"])
def listar_minerais():
    with conectar() as con:
        con.row_factory = sqlite3.Row
 
        minerais = con.execute(
            "SELECT * FROM minerais ORDER BY id"
        ).fetchall()
 
        return jsonify([dict(m) for m in minerais])
 
 
@app.route("/api/minerais", methods=["POST"])
def cadastrar_mineral():
    dados = request.get_json(silent=True) or {}
 
    nome = str(dados.get("nome", "")).strip()
    categoria = str(dados.get("categoria", "")).strip()
    origem = str(dados.get("origem", "")).strip()
    status = str(dados.get("status", "")).strip()
    simbolo = nome[:2].upper()
 
    try:
        quantidade = float(dados.get("quantidade"))
 
        if quantidade < 0:
            raise ValueError
 
    except (TypeError, ValueError):
        return jsonify({"erro": "Quantidade inválida."}), 400
 
    if not nome or not categoria or not origem or not status:
        return jsonify({"erro": "Preencha todos os campos."}), 400
 
    try:
        with conectar() as con:
            con.row_factory = sqlite3.Row
 
            cursor = con.execute("""
                INSERT INTO minerais
                (nome, categoria, quantidade, origem, status, simbolo)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                nome,
                categoria,
                quantidade,
                origem,
                status,
                simbolo
            ))
 
            novo = con.execute(
                "SELECT * FROM minerais WHERE id = ?",
                (cursor.lastrowid,)
            ).fetchone()
 
            return jsonify(dict(novo)), 201
 
    except sqlite3.IntegrityError:
        return jsonify({
            "erro": "Esse mineral já está cadastrado."
        }), 409
 
 
if __name__ == "__main__":
    criar_banco()
    app.run(debug=True)
 
 