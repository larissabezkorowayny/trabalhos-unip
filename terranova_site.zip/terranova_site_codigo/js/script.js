const minerais = [];
 
const grid = document.querySelector("#mineralGrid");
const search = document.querySelector("#searchMineral");
const filter = document.querySelector("#filterStatus");
const form = document.querySelector("#mineralForm");
const msg = document.querySelector("#formMessage");
 
const fmt = n =>
    new Intl.NumberFormat("pt-BR").format(n) + " kg";
 
function render() {
    const termo = search.value.trim().toLocaleLowerCase("pt-BR");
 
    const lista = minerais.filter(m =>
        m.nome.toLocaleLowerCase("pt-BR").includes(termo) &&
        (filter.value === "todos" || m.status === filter.value)
    );
 
    grid.innerHTML = "";
 
    if (lista.length === 0) {
        grid.textContent = "Nenhum mineral encontrado.";
    } else {
        lista.forEach(m => {
            const card = document.createElement("article");
 
            card.innerHTML = `
                <div class="symbol">${m.simbolo}</div>
                <span class="status ${m.status === "Baixo estoque" ? "low" : ""}">
                    ${m.status}
                </span>
                <h3>${m.nome}</h3>
                <p>${m.categoria}</p>
                <p>Origem: ${m.origem}</p>
                <div class="quantity">
                    Quantidade disponível: <b>${fmt(m.quantidade)}</b>
                </div>
            `;
 
            grid.appendChild(card);
        });
    }
 
    document.querySelector("#totalMinerais").textContent =
        minerais.length;
 
    document.querySelector("#totalEstoque").textContent =
        fmt(minerais.reduce((s, m) => s + Number(m.quantidade), 0));
}
 
async function carregarMinerais() {
    try {
        const resposta = await fetch("/api/minerais");
 
        if (!resposta.ok) {
            throw new Error("Erro ao carregar minerais.");
        }
 
        const dados = await resposta.json();
 
        minerais.splice(0, minerais.length, ...dados);
        render();
    } catch (erro) {
        console.error(erro);
        msg.textContent = "Não foi possível carregar os minerais.";
    }
}
 
search.addEventListener("input", render);
filter.addEventListener("change", render);
 
form.addEventListener("submit", async e => {
    e.preventDefault();
 
    const d = new FormData(form);
 
    const nome = String(d.get("nome") || "").trim();
    const categoria = String(d.get("categoria") || "").trim();
    const origem = String(d.get("origem") || "").trim();
    const status = String(d.get("status") || "").trim();
    const quantidade = Number(d.get("quantidade"));
 
    if (
        !nome ||
        !categoria ||
        !origem ||
        !status ||
        !Number.isFinite(quantidade) ||
        quantidade < 0
    ) {
        msg.textContent = "Confira os campos do formulário.";
        return;
    }
 
    try {
        msg.textContent = "Salvando mineral...";
 
        const resposta = await fetch("/api/minerais", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                nome,
                categoria,
                origem,
                status,
                quantidade
            })
        });
 
        const resultado = await resposta.json();
 
        if (!resposta.ok) {
            msg.textContent =
                resultado.erro || "Não foi possível salvar o mineral.";
            return;
        }
 
        await carregarMinerais();
 
        form.reset();
        msg.textContent = "Mineral salvo no banco de dados!";
 
    } catch (erro) {
        console.error(erro);
        msg.textContent = "Erro ao conectar com o servidor.";
    }
});
 
document.querySelector("#menuToggle").addEventListener("click", () => {
    document.querySelector("#navMenu").classList.toggle("open");
});
 
document.querySelectorAll("#navMenu a").forEach(a => {
    a.addEventListener("click", () => {
        document.querySelector("#navMenu").classList.remove("open");
    });
});
 
carregarMinerais();
 
 